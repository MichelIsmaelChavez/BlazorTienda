self.assetsManifest = {
  "version": "9zlGHq/3",
  "assets": [
    {
      "hash": "sha256-lDc70XxQORoINruF7eAWOzBJV2qaptX4oX7xVljuRo8=",
      "url": "BlazorTienda.styles.css"
    },
    {
      "hash": "sha256-RVHAV+YHzVfC1EjXvj2S9xfey8M2SAB9AFx9aHoEcxw=",
      "url": "_framework/BlazorTienda.vfsr2h85cq.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-dNXm5uttEd+wv/2Ctuldrp1y1wYAjCNA8huFzkOBRrg=",
      "url": "_framework/Microsoft.AspNetCore.Components.0755tpcqpt.wasm"
    },
    {
      "hash": "sha256-V9ttpAY74fNEjoJEKbC6wvqj1BjRfApaJtUGDvTgrMY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vq9g6cpll0.wasm"
    },
    {
      "hash": "sha256-v5n+N7E+z36uGfEYxI/leNbYeUOYTPOe4eJdv4XlHwg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.9ap9ybdpyp.wasm"
    },
    {
      "hash": "sha256-OeomjbaPGVBV1erDXsxswNj2t3Byu9/ZmRQYCCgP+dM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.1i3m7m7pwr.wasm"
    },
    {
      "hash": "sha256-UmR62Lv+cAcCu+K11neXM60ezRGWQeblRFgYcpyiB3o=",
      "url": "_framework/Microsoft.AspNetCore.WebUtilities.24c42b43sf.wasm"
    },
    {
      "hash": "sha256-V/8lrAHQfJYsJtV+bKRHL6fmMFhJhAOyoTNfGTbwTdQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.7sm4vp77d1.wasm"
    },
    {
      "hash": "sha256-M/V9DIZ9otM7/qEt+xn3wagkoRiLOf4JMPyDoo6WUM8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.n3roazub70.wasm"
    },
    {
      "hash": "sha256-XQykit2HYxnB0emmOc5bra6XuZq3KgCfazi8kFAErDs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.jgtmx19396.wasm"
    },
    {
      "hash": "sha256-nD3jgnWqsSQAhEig/5B6waVKSjoBP6URT4JAqosEjPc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.cwtp2ytso6.wasm"
    },
    {
      "hash": "sha256-wPj/fOeoE7JKOgIYh6OIvl/k3Iw6EPDmmXDjtnQ6rJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g0r86u4i0h.wasm"
    },
    {
      "hash": "sha256-fV7IXTWmfzVLjp/qzwDvMNTnIYvFY4mbQa67kGJSUNk=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.tgqm3v3hul.wasm"
    },
    {
      "hash": "sha256-5E3YJsqbWNbv+OJiZ1kCoV5czf1fXeUBZBKig0eHQKs=",
      "url": "_framework/Microsoft.Extensions.Logging.km3zhtnk76.wasm"
    },
    {
      "hash": "sha256-ueRCTgiDMRoeRGmcGybrwwZ5wIj057NNM45ToRsvRcU=",
      "url": "_framework/Microsoft.Extensions.Options.x25gjdmbax.wasm"
    },
    {
      "hash": "sha256-bj0VlheObDK+lpW/HriQhXfg8/aaSgmPSQ9WIy9cpxw=",
      "url": "_framework/Microsoft.Extensions.Primitives.au1918dnmx.wasm"
    },
    {
      "hash": "sha256-hbzWuXrlepIqY/y+nQ2ZAFer2/njy1dc+Y4LUaAaL5E=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.p386u0jty9.wasm"
    },
    {
      "hash": "sha256-lzbPwg8nj4ACs3tkTjg8gE/fkGVQ+ZLqKUnaieFAtow=",
      "url": "_framework/Microsoft.JSInterop.fyg7lw3kth.wasm"
    },
    {
      "hash": "sha256-aulKu7rlMKRjegkpWAa7cRIghnMJ39qqX9n94NIydDY=",
      "url": "_framework/System.Collections.61g1m7xenj.wasm"
    },
    {
      "hash": "sha256-YiAlVyPYpZGjUQvuTZAaWBtVF7u9iIMctDcqom6CQYk=",
      "url": "_framework/System.Collections.Concurrent.mayoka2cdq.wasm"
    },
    {
      "hash": "sha256-irPwgQff/Pp6rcDRPX0A2TEhbT2w5nct1yJQgdwGrMQ=",
      "url": "_framework/System.Collections.Immutable.mhd9z5t0b5.wasm"
    },
    {
      "hash": "sha256-tptG8WXmOXmueFkJUXHRa4AVphnUmvz++F/3H5wtNNU=",
      "url": "_framework/System.Collections.NonGeneric.e3ptc19yer.wasm"
    },
    {
      "hash": "sha256-1XYXtW2UvQtN9nreTufMrVy4rOtsPjRvJ8zyUycbXLs=",
      "url": "_framework/System.Collections.Specialized.d2wudb8n7e.wasm"
    },
    {
      "hash": "sha256-JNR/o2tUFaDeOk9pghPZD2sAdWEKA2OUJ2ONln9UeD0=",
      "url": "_framework/System.ComponentModel.076m38u6l8.wasm"
    },
    {
      "hash": "sha256-nnjVtT7I7Z23acC/S68ayg5fqFtLJDd6nAfirPEogvU=",
      "url": "_framework/System.ComponentModel.Annotations.q24nn3zqbw.wasm"
    },
    {
      "hash": "sha256-p6IeaX49Jlz6DAR08NwEhUVX8iO/52ymOekpttXFb7I=",
      "url": "_framework/System.ComponentModel.Primitives.5dgimd5jg7.wasm"
    },
    {
      "hash": "sha256-xDdRa3Jq3AdigV7VqJpA41eJUf876MRq7s7msVfdPXs=",
      "url": "_framework/System.ComponentModel.TypeConverter.0t3qa6sr84.wasm"
    },
    {
      "hash": "sha256-Y4NIMfrZ43sMuvvoL2ezi5KGYN2qkqchH7s9Y9MJskw=",
      "url": "_framework/System.Console.7n67arx7bd.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-uP9JkPmH2vDsqIukyRjarfx3L+Gh6hJN8Mxd4QWRtNA=",
      "url": "_framework/System.Linq.45dvkyx90x.wasm"
    },
    {
      "hash": "sha256-/buzz3D5/zdOTY18RYso1bf7VV7/JJogzWQ8TbgtpNQ=",
      "url": "_framework/System.Linq.Expressions.lacfoyrpl2.wasm"
    },
    {
      "hash": "sha256-1dpyDzvLho/xSWtrIhVojAwWyHhYKeXdx8ssZyMJxkY=",
      "url": "_framework/System.Linq.Queryable.b8oenfen75.wasm"
    },
    {
      "hash": "sha256-tCznIAaQdysSsBlri4JhpkOJQ4Nhsopc01TKAJP/ByY=",
      "url": "_framework/System.Memory.gxk30wm3qo.wasm"
    },
    {
      "hash": "sha256-IwGUdCFT/bTrVsSeM+GH+p7lNj/QctorMQ3XHOM4lus=",
      "url": "_framework/System.Net.Http.xjt5e7pw25.wasm"
    },
    {
      "hash": "sha256-nB5JS/nQn/pNhPGXYrb1uDoDn3cuo9TQKE1RKnVa648=",
      "url": "_framework/System.Net.Primitives.8x3nzqo64g.wasm"
    },
    {
      "hash": "sha256-wNfPvrHDu12m8nAsDGzNZQk23FT+Jj3h9Ewtkzk8Yuc=",
      "url": "_framework/System.ObjectModel.wgm2i2b0yp.wasm"
    },
    {
      "hash": "sha256-hOf/t2Kwiglfcuir2ixkqq+9WmmK69SmefJheIkMhJA=",
      "url": "_framework/System.Private.CoreLib.onnvijyzn2.wasm"
    },
    {
      "hash": "sha256-59A1ovFHkkHzWoMb0sps5ch2psei7feGhWRZMQIbmnE=",
      "url": "_framework/System.Private.Uri.lxu2qvrpxq.wasm"
    },
    {
      "hash": "sha256-tE7jkQz8vnZiyD7Ut125gXhOzzTmJVpyZ9xejVgOghY=",
      "url": "_framework/System.Runtime.48truh4y1i.wasm"
    },
    {
      "hash": "sha256-t5fC5E2r9YJ+puOWw7YuXXMwvd7LxeR0Zt16THexNM0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.zp9u3yqbi4.wasm"
    },
    {
      "hash": "sha256-NmYMQHBLs7lgIXDfLv3qMr2BXadxAMWLjqs3C6djLCw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.6wjui9dnma.wasm"
    },
    {
      "hash": "sha256-pdKoJJI3yt1NF2Lx1MGO++1RtPSzree8qeWFFtJOnKo=",
      "url": "_framework/System.Text.Encodings.Web.5w28q6ifw5.wasm"
    },
    {
      "hash": "sha256-TBm2cNrk+LFQiVwo1lVlNV+CQmklp9hKG09wRwQxG1U=",
      "url": "_framework/System.Text.Json.kadwmir40r.wasm"
    },
    {
      "hash": "sha256-A29j8BigKS89/5EBW6GETUPxSN+JNi8uuKehrofYFmE=",
      "url": "_framework/System.Text.RegularExpressions.3kr2n0wcz9.wasm"
    },
    {
      "hash": "sha256-F5PSI/gBuwoWEF7SbdO7+2/Lo9hw0ISBKug8avOpxP0=",
      "url": "_framework/System.Threading.vuopdrx302.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-OjeGT9sFlwwwQsXS09msbYBn4h9lXDIVactrecuSsro=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-89jyB8DlCnV2BPMV477jOe1Sm0WXwVf8RuoSPsj4Ym8=",
      "url": "_framework/dotnet.native.3c4wvb350q.wasm"
    },
    {
      "hash": "sha256-LX9rFEWGVxhkOkAVPG0w5RxPwzPBlEUz6dQNjWS7M+M=",
      "url": "_framework/dotnet.native.hvg7u8bimp.js"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-qBYB32GG45gcIJ/PCTZ2PpzLAfErzhwVi9pdl82KQVg=",
      "url": "css/Delivery.css"
    },
    {
      "hash": "sha256-LAsltajypH11sjKt5/Etc8Ln6hFR4uu1WrIBmCsx4nU=",
      "url": "css/Entregas.css"
    },
    {
      "hash": "sha256-ZlxoMc0RzDpZdPJTkrkmDUXL897Brxv7akWiP8fePa4=",
      "url": "css/Menu.css"
    },
    {
      "hash": "sha256-sKs+Gzso1jHBEANCiSe/u6eZexMS8bX8yOyETw+E7q4=",
      "url": "css/Ofertas.css"
    },
    {
      "hash": "sha256-3pGmvXH5iIjSVOrgcq8oIl+r0c40vaCZ6mxyPTrrilw=",
      "url": "css/Producto.css"
    },
    {
      "hash": "sha256-u4DszuiY1WLPnENub5+KbAlwyJCcCHdKlyaXaKLaRqk=",
      "url": "css/categoria.css"
    },
    {
      "hash": "sha256-JudufL1l7STR0hPbE9fphZyg6t/RboWUtD9AXLFyxc4=",
      "url": "css/chat.css"
    },
    {
      "hash": "sha256-w1x7W0XCBMW7bzbQzNJXo2UIoX7Z+Kag/Tu5l0uJQAU=",
      "url": "css/historialcompras.css"
    },
    {
      "hash": "sha256-PWy4uNnlCGR1i6PkAnbSfCZKBqPP2f9H/ucnheLcVUY=",
      "url": "css/layout.css"
    },
    {
      "hash": "sha256-EtuPlDmmZ0NayuW0/9Js+C0oudSr3/6i/2DISaWY/ik=",
      "url": "css/login.css"
    },
    {
      "hash": "sha256-Hq3dIHcbLaqb9gi9BcI3ag7BWZI+ghjdbNzzQA/1I6s=",
      "url": "css/registro.css"
    },
    {
      "hash": "sha256-9zx4KI5AIjXywjbRcL1+ZCSLt6yBY5Yh1EBqwok1ED8=",
      "url": "css/reportedelivery.css"
    },
    {
      "hash": "sha256-EgmJVkUK4nyd33na5XEWqpgaCnyi39ngSS/8wZ+mUUc=",
      "url": "css/site.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-OrAXBzzfQJxZ16uaZ3F9Fc0LmdOQXuc6p6iq9wjUlHk=",
      "url": "images/logox.png"
    },
    {
      "hash": "sha256-BTYxW1q8hWtIRWWYDlLFBriD/8032U0NRw0+fmnKXjo=",
      "url": "images/pikachu.png"
    },
    {
      "hash": "sha256-L+5I5XpJJjWsVrz2RoIvY8lW8YHMVixwLSEbtXeV5i8=",
      "url": "images/promos/promo1.jpg"
    },
    {
      "hash": "sha256-w80yrkWprHUN3fIrXYCgS2In6D/2FYpu9Sx/uwITBug=",
      "url": "images/promos/promo2.jpg"
    },
    {
      "hash": "sha256-bwoNf/AyrvfC4Yf6q9hcN/7e2v2n5wIWEOxbzo+Frqo=",
      "url": "images/promos/promo3.jpg"
    },
    {
      "hash": "sha256-6k+t3o7aTmnfS4NaLo53vl4Czc6DH6LY9CgfNXWcPPg=",
      "url": "img/Electrodomésticos.jpg"
    },
    {
      "hash": "sha256-tupy6GMkJpoM/J4vvysmusNNJ0b9VNKHnuJRMKcWVBs=",
      "url": "img/Moto.jpg"
    },
    {
      "hash": "sha256-xXwer4Z7IsPE5jdNSdRf9Of+G1nY1CLtbs8rczwtpY4=",
      "url": "img/Ropa.jpg"
    },
    {
      "hash": "sha256-0UtQTsqWA1Na2B2H8flZrVVHsb+clNySCd9MhvLAbjY=",
      "url": "img/Tecnología.jpg"
    },
    {
      "hash": "sha256-lF0fikxnU/ejAp09mGQyIXIqYfaJYK15itmNuDqd85Y=",
      "url": "img/auriculares.jpg"
    },
    {
      "hash": "sha256-pqUI6AKBt8W7xu9EwpL2HRfoRBZdS6gpQ+8dsxZHwjQ=",
      "url": "img/campera.jpg"
    },
    {
      "hash": "sha256-dxOLXQerXY6x5f9EHJcjdr2AM/y9WxAioN5kdsukt5E=",
      "url": "img/casco.jpg"
    },
    {
      "hash": "sha256-lkWQXlSJfsYuR09C0HYCk8LQ1HFmSK8epEhMwQ3jB3s=",
      "url": "img/escritorio.jpg"
    },
    {
      "hash": "sha256-ypDwy3eCuScV+0Ktc5XXy8Qif1fKSwVE0krSb/vb1CQ=",
      "url": "img/guantes.jpg"
    },
    {
      "hash": "sha256-V/RZF5mVGYSlTjFp6tiVc4E23+3pwf501iyyq62q3Ag=",
      "url": "img/laptop.jpg"
    },
    {
      "hash": "sha256-jxZ90AR2iDa0DLjoYyc1kx+JkurYvRuqABWswKP2nJU=",
      "url": "img/microondas.jpg"
    },
    {
      "hash": "sha256-Ia87fut+t9jz60U11HFQEni21nG7QbJozZR6flRiWPY=",
      "url": "img/ps5.jpg"
    },
    {
      "hash": "sha256-8gMwzXJ0OLOVXE/gTW68uDTl30EmF0yUFpckpc8uwQo=",
      "url": "img/refrigerador.jpg"
    },
    {
      "hash": "sha256-sjcQJMvimiGiGguqYL3PWaL3FQsSgqWOXqDIaRoVnDY=",
      "url": "img/sillon.jpg"
    },
    {
      "hash": "sha256-N4M/GwBHzQt13aXICRNThOlkd99LynUXiFNAvAJqxMc=",
      "url": "img/smartphone.jpg"
    },
    {
      "hash": "sha256-STm/28pbcqwDLbjbX4aYJBNApy33aDLsUj8HcBiSuwM=",
      "url": "img/switch.jpg"
    },
    {
      "hash": "sha256-hvlp6pPKFgBCIoeCheSB0MKQVbsskTqcI8+EUZ1d8wU=",
      "url": "img/tablet.jpg"
    },
    {
      "hash": "sha256-OTbMxRD0W/QxM/4daquRGng09MNEBNsIpDbf8CoNbH8=",
      "url": "img/zapatillas.jpg"
    },
    {
      "hash": "sha256-xxf5hC9KyFt6Dt7EJ0k1rjKZzM8mMLcct1KhBahfx9U=",
      "url": "index.html"
    },
    {
      "hash": "sha256-E90bTdKH2Rh4oAJiT6pvTQUePX0aXnV1GzqccFswams=",
      "url": "js/Entrega.js"
    },
    {
      "hash": "sha256-q4nz0bQfYKXykFQv46Khwtx3zVEa7TiK91SBZ1WcwwQ=",
      "url": "js/camara.js"
    },
    {
      "hash": "sha256-Ed67d3uTrZApC76dD1IgOY6WfmTD7M3t2JO1OpvVEcI=",
      "url": "js/cliente.js"
    },
    {
      "hash": "sha256-Uxxv0UKs3gfoAEcXsKImESB9KvKBloubnH2tU7g5Af8=",
      "url": "js/dashboard.js"
    },
    {
      "hash": "sha256-fGDF3pIOl/aJNhjwpXez90BW6Ocq9QmJ8WxuTP/NUBE=",
      "url": "js/exporter.js"
    },
    {
      "hash": "sha256-s7C903GWp3jYivM02qaXlzQx6Aqgt94XMP1dfN9fPN0=",
      "url": "js/mapa.js"
    },
    {
      "hash": "sha256-oGUP8Z1utLwZ/jYzdcEtJOcjoVXF9ThKIBIhMthpRhE=",
      "url": "js/mapaEntrega.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-QFIZaooki1m/1PjQvMWgXFPSlmK9bE3IDVsPipzak/4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-BoDnoR3mdAr060UTVa0bHo0afAr47r+lwFWXhriigSY=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-OFnIRyvLhl7cXOzUMPXIzNVazm85p0LZhSZkSM3vb0Q=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-lR9WQw4+t4ij6Dv/FkzZExFFPUD0mM407C0bsjdTSZ8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-M04ztRMERktzCqsd5mM+sIzbyYVggI8UC/b8hCHJQa4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-3aMYh/4rsYhFqmQmTl8u8iq9rB3gMYPXBBRxEvrcANE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-H2Pvudf4nHsKDfRpFzwToOYZRBfxKCuhDY/BM4MP3Jk=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-c6ISf8qzZ05l8hCvdKMiMg/L/qNT7VZ+nRGcOTNuUec=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-YujiNfREg4iYE/KQKcaFvFCpitjYkb98GYtw1AdJElA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-XbLQb+5WsPX8iHa/yf97fwGx7aF/XyBJvv8HfmxeIZo=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-su+fsc6necURHFCiDGeUvWTbTHbTl0E4M+aPWAkyw6s=",
      "url": "models.rar"
    },
    {
      "hash": "sha256-RhHvZch9g20D1oSzDuxNGV2LIZ+h3Vj8WJRYMca5KZs=",
      "url": "models/face_landmark_68_model-shard1"
    },
    {
      "hash": "sha256-0w9sw0EAnqT4Ijh2lZKJuWV2/FSiYV+S2pdBq5xfC7w=",
      "url": "models/face_landmark_68_model-weights_manifest.json"
    },
    {
      "hash": "sha256-QSVmorjYFNhMYLgFXsXTs7IyjvfNeFM4TgPsPbewU9g=",
      "url": "models/face_recognition_model-shard1"
    },
    {
      "hash": "sha256-aTUP3s2EXFMuRN2PfQUhx3NQXvRrh8w09GZAoMwzTsw=",
      "url": "models/face_recognition_model-shard2"
    },
    {
      "hash": "sha256-Zhn0Em+EXB94V/OcvXlWXzdXNPRuDdJdlgL43CHNqfU=",
      "url": "models/face_recognition_model-weights_manifest.json"
    },
    {
      "hash": "sha256-b/FvCVsDcfJKzLSKq4LllWl7qoIc+FEWfL+SA9HX7Jo=",
      "url": "models/ssd_mobilenetv1_model-shard1"
    },
    {
      "hash": "sha256-JTmEfmJ8jEpWHpmRcHNebFJ97sxv26KVn8UxL7HqHeM=",
      "url": "models/ssd_mobilenetv1_model-shard2"
    },
    {
      "hash": "sha256-m4SRjR2LLpiNxdcsDXfnzAo9Qz8kUlFvzYjcqAUbVS8=",
      "url": "models/ssd_mobilenetv1_model-weights_manifest.json"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    },
    {
      "hash": "sha256-9L5dvb6/iJsFO5khNeUZtBdGf5XMOC62RQGhyJYl664=",
      "url": "scripts/reconocimiento.js"
    },
    {
      "hash": "sha256-0YXhHv6I17CIzQDuVOGSZAk9CfXk79qUGTad2d30Z+E=",
      "url": "sounds/notification.mp3"
    }
  ]
};
